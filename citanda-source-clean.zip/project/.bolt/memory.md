# Project memory

## Product intent & audience

- Citanda Digital Marketplace: digital commerce platform built from scratch for the Angolan market.
- Public store browsing, secure Supabase authentication, customer portal, protected admin dashboard.
- UI/content in Portuguese (Angolan audience).

## Brand personality & voice

- Professional, production-grade commerce platform; tone is formal, clear, Portuguese-language.

## Visual design & UX direction

- Homepage includes a "Mais bem avaliados" (top-rated) section.
- Public review reporting: visible report button for visitors.
- Admin moderation UI exists (hide/show/report reviews) and must call secure RPC, not direct table writes.
- WhatsApp integration is unified and validated across the app.

## Decisions, constraints & rationale

- Development is organized in numbered phases; Phase 7 and Phase 8 are complete.
- Security hardening: review-related columns are protected; direct writes from client are disallowed.
- Three Supabase RPC functions are the canonical interfaces for review actions:
  - `report_review` — public, any visitor can report a review (increments counter + stores reason).
  - `reviewer_name` — resolves author display name (e.g. returned "João Torres" in tests).
  - `admin_moderate_review` — admin-only moderation (hide/show/report).
- Permission model verified: visitors can report but not edit; only admins can moderate.
- Admin review moderation must use `admin_moderate_review` RPC (previous direct-column approach would fail post-hardening).
- Final typecheck and build pass cleanly.

## Open questions & assumptions

- Assumption: phase numbering continues beyond 8; future phases not yet specified.
- No stated direction for styling theme/colors beyond "beautiful, not cookie cutter" (see `.bolt/prompt`).
- Assumption: Supabase remains the sole auth/data layer; no additional backend introduced.